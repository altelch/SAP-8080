The original DRI sources and patch notes are archived at:
http://www.cpm.z80.de/source.html.

Modifications done to the sources:

SYSGEN.ASM	changed skew from to 2 to 1 for Z80SIM

Application Notes and Patches from DRI applied:

Note/Patch	File affected	Description
------------------------------------------------------------------------------
CPM22APN.02	OS3BDOS.ASM	make RUBOUT identical to BACKSPACE
CPM22PAT.03	SUBMIT.PLM	Create $$$.SUB always on A:, so that a
				submit job can run from any drive
CPM22APN.12	SUBMIT.PLM	Do not convert input to upper case

To build everything on drive d:

	submit cmd1
	submit cmd2 <- this will break ed, don't execute, needs to be fixed
	submit cmd3
	submit cmd4
	submit cmd5

For the kernel (MOVCPM) there are two choices:

	submit kernel-m	build for Intel MDS800, as it was distributed by DRI
	submit kernel-s build for Z80 simulator

For Z80 simulator then execute:

	d:movcpm 64 *
	save 34 d:cpm64.sys
	d:sysgen d:cpm64.sys

The movcpm program might report a synchronization error and HALT the machine.
To overcome the problem run it under control of ddt and patch out the jumps
to the error handler as follows:

	ddt d:movcpm.com
	s234
	0
	0
	0
	.
	s2cb
	0
	0
	0
	.
	i64 *
	g

Write the kernel to system tracks in drive d and try out the disk with
the compiled system.

The batch file sysgen.sub can be used to patch other boot code and BIOS
into a CP/M kernel, or build one for another system.

May 2008, Udo Munk
